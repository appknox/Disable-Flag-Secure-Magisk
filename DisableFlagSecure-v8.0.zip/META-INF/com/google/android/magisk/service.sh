#!/system/bin/sh
cleaner() {
   rm -f "/data/dalvik-cache/arm/system@framework@services.jar@classes.dex"
        
   rm -f "/data/dalvik-cache/arm/system@framework@services.jar@classes.vdex"
        
   rm -f "/data/dalvik-cache/arm64/system@framework@services.jar@classes.dex"
       
   rm -f "/data/dalvik-cache/arm64/system@framework@services.jar@classes.vdex"
        
    
}

cleaner

exit 0
